namespace RedMujer_Backend.DTOs
{
    public class EmprendimientoCategoriaDto
    {
        public int IdCategoria { get; set; }
        public int IdEmprendimiento { get; set; }
    }
}
