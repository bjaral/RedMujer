namespace RedMujer_Backend.DTOs
{
    public class PersonaEmprendimientoDto
    {
        public int IdPersona { get; set; }
        public int IdEmprendimiento { get; set; }
    }
}
