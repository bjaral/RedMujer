namespace RedMujer_Backend.DTOs
{
    public class EmprendimientoUbicacionDto
    {
        public int IdUbicacion { get; set; }
        public int IdEmprendimiento { get; set; }
    }
}
