Configurar el archivo appsettings.json con tu conexión a la base de datos 

Ejecutar la app:
dotnet run

Abrir Swagger para probar los endpoints en:
http://localhost:5145/swagger/index.html
eso es para probar el backend ,en el link deberia aparecerles /api/Emprendimientos y otros endpoints, solamente mofician el link http://localhost:5145 agregando el endpoint que quieran probar y deberia funcionar

TABLAS TERMINADAS:
- Emprendimiento
- Usuario
