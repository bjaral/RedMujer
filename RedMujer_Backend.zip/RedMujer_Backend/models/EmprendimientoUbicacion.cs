namespace RedMujer_Backend.models
{
    public class EmprendimientoUbicacion
    {
        public int IdUbicacion { get; set; }
        public int IdEmprendimiento { get; set; }
    }
}
