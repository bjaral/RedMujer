namespace RedMujer_Backend.models
{
    public class EmprendimientoCategoria
    {
        public int IdCategoria { get; set; }
        public int IdEmprendimiento { get; set; }
    }
}
