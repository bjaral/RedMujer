namespace RedMujer_Backend.models
{
    public class PersonaEmprendimiento
    {
        public int IdPersona { get; set; }
        public int IdEmprendimiento { get; set; }
    }
}
